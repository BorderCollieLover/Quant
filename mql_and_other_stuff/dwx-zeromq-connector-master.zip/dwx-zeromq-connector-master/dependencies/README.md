This project incorporates functionality authored by Ding Li (GitHub: https://github.com/dingmaotu), who has kindly licensed his work under the Apache 2.0 license.

We acknowledge copyright as per the terms of the license, the following repositories serving as mandatory dependencies for this project:

1. https://github.com/dingmaotu/mql-zmq

1. https://github.com/dingmaotu/mql4-lib

Thank you Ding for your amazing open source contribution to this space!

Sincerely,<br>
The Darwinex Labs Team<br>
www.darwinex.com
